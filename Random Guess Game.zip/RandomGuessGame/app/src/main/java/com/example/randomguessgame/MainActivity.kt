package com.example.randomguessgame

import android.annotation.SuppressLint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import com.google.android.material.textfield.TextInputEditText
import kotlin.random.Random

class MainActivity : AppCompatActivity() {
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val nextValues = List(1) { Random.nextInt(1, 100) }
        var TextDisplay = findViewById<TextView>(R.id.textView)
        var InputValue = findViewById<TextInputEditText>(R.id.inputter)
        var button = findViewById<Button>(R.id.button)

        button.setOnClickListener {
            if(InputValue.text == nextValues) {
                TextDisplay.text = "Correct"
            } else {
                TextDisplay.text = "Wrong" + '\n' + nextValues.toString()
            }
        }
    }
}